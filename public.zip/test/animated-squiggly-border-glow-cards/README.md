# Animated Squiggly Border Glow Cards

A Pen created on CodePen.

Original URL: [https://codepen.io/TheMOZZARELLA/pen/vEOdYLZ](https://codepen.io/TheMOZZARELLA/pen/vEOdYLZ).

Responsive glow cards with squiggly animated svg borders.